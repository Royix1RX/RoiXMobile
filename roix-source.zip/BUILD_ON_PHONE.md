# Build RoiX Mobile from an Android phone

This project includes a GitHub Actions workflow that can compile a debug APK in the cloud.
You need a GitHub account. ChatGPT cannot sign in to or create a repository in your account.

## Steps

1. Download and extract `RoiXMobile_v0.1_source.zip`.
2. In your phone browser, open https://github.com/new and create a repository named `RoiXMobile`.
3. Upload the extracted project files and folders to the repository. Make sure the `.github/workflows/android-debug.yml` file is included.
   - If GitHub's mobile upload interface does not show hidden folders, use the repository's **Add file → Create new file** option and create `.github/workflows/android-debug.yml`, then paste the workflow contents from this project.
4. Open the repository's **Actions** tab.
5. Select **Build RoiX Mobile APK** and tap **Run workflow** (or push to `main` to trigger it).
6. Wait for the workflow to finish. Open the successful run and download the `RoiXMobile-debug-apk` artifact.
7. Extract the artifact ZIP to get `app-debug.apk`. Android may ask you to allow installation from that browser/file manager.

## Important

- This workflow produces a **debug APK**, not a signed Play Store release.
- The build has not yet been run in this environment. GitHub Actions will reveal any compiler or dependency issues; share the error log if it fails.
- v0.1 is only a browser/API-key/background-service foundation. It does not yet automate Qureo lessons or guarantee WebView operation while another app is in front or the screen is off.
- The Gemini key is encrypted at rest using Android Keystore, but a key used directly in a mobile client can still potentially be extracted at runtime. A private backend is recommended before public distribution.
