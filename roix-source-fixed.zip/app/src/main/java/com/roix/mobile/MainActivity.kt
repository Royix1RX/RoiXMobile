package com.roix.mobile

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : ComponentActivity() {
    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent { RoiXApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RoiXApp() {
    val context = LocalContext.current
    val keyStore = remember { ApiKeyStore(context) }
    val scope = rememberCoroutineScope()
    var address by remember { mutableStateOf("https://qureo.jp/") }
    var apiKey by remember { mutableStateOf(keyStore.read().orEmpty()) }
    var showKey by remember { mutableStateOf(false) }
    var geminiStatus by remember { mutableStateOf(if (apiKey.isBlank()) "Not connected" else "Key saved · not tested") }
    var activityStatus by remember { mutableStateOf("Ready · automation engine not connected") }
    var serviceRunning by remember { mutableStateOf(false) }
    var webView by remember { mutableStateOf<WebView?>(null) }
    var pageTitle by remember { mutableStateOf("Open Qureo to begin") }

    MaterialTheme(colorScheme = darkColorScheme()) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("RoiX Mobile")
                            Text("Browser-first learning assistant", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Card {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Browser", style = MaterialTheme.typography.titleMedium)
                        OutlinedTextField(
                            value = address,
                            onValueChange = { address = it },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            label = { Text("Website address") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri)
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = {
                                val target = if (address.startsWith("http")) address else "https://$address"
                                address = target
                                webView?.loadUrl(target)
                            }) { Text("Go") }
                            OutlinedButton(onClick = { webView?.goBack() }) { Icon(Icons.Default.ArrowBack, null) }
                            OutlinedButton(onClick = { webView?.goForward() }) { Icon(Icons.Default.ArrowForward, null) }
                            OutlinedButton(onClick = { webView?.reload() }) { Icon(Icons.Default.Refresh, null) }
                        }
                        Text(pageTitle, style = MaterialTheme.typography.bodySmall)
                        AndroidView(
                            modifier = Modifier.fillMaxWidth().height(390.dp),
                            factory = { ctx ->
                                WebView(ctx).apply {
                                    settings.javaScriptEnabled = true
                                    settings.domStorageEnabled = true
                                    settings.loadsImagesAutomatically = true
                                    webViewClient = object : WebViewClient() {
                                        override fun onPageFinished(view: WebView, url: String) {
                                            address = url
                                            pageTitle = view.title ?: url
                                        }
                                    }
                                    webChromeClient = WebChromeClient()
                                    loadUrl(address)
                                    webView = this
                                }
                            },
                            update = { webView = it }
                        )
                    }
                }

                Card {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Gemini AI", style = MaterialTheme.typography.titleMedium)
                        Text(geminiStatus, color = MaterialTheme.colorScheme.secondary)
                        Text("API key", style = MaterialTheme.typography.labelLarge)
                        OutlinedTextField(
                            value = apiKey,
                            onValueChange = { apiKey = it },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            label = { Text("Gemini API key") },
                            visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                            trailingIcon = {
                                IconButton(onClick = { showKey = !showKey }) {
                                    Icon(if (showKey) Icons.Default.VisibilityOff else Icons.Default.Visibility, "Show or hide key")
                                }
                            }
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = {
                                keyStore.save(apiKey.trim())
                                geminiStatus = if (apiKey.isBlank()) "No key saved" else "Key saved securely on this device · not tested"
                            }) { Text("Save key") }
                            OutlinedButton(enabled = apiKey.isNotBlank(), onClick = {
                                keyStore.save(apiKey.trim())
                                geminiStatus = "Testing connection…"
                                scope.launch {
                                    geminiStatus = testGemini(apiKey.trim())
                                }
                            }) { Text("Test connection") }
                        }
                        Text(
                            "Security note: the key is encrypted at rest with Android Keystore. A key used directly by a mobile app can still potentially be extracted at runtime; a private backend is safer for a public release.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                }

                Card {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Automation", style = MaterialTheme.typography.titleMedium)
                        Text(activityStatus, color = MaterialTheme.colorScheme.secondary)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = {
                                activityStatus = "Requested start · automation engine is not implemented yet"
                                serviceRunning = true
                                val intent = Intent(context, RoiXService::class.java).setAction(RoiXService.ACTION_START)
                                ContextCompat.startForegroundService(context, intent)
                            }) { Text("Start") }
                            OutlinedButton(onClick = {
                                activityStatus = "Paused · no website actions are running in this build"
                                context.startService(Intent(context, RoiXService::class.java).setAction(RoiXService.ACTION_PAUSE))
                            }) { Text("Pause") }
                            OutlinedButton(onClick = {
                                activityStatus = "Stopped"
                                serviceRunning = false
                                context.startService(Intent(context, RoiXService::class.java).setAction(RoiXService.ACTION_STOP))
                            }) { Text("Stop") }
                        }
                        OutlinedButton(onClick = {
                            activityStatus = "Take Control · browser is yours"
                        }, modifier = Modifier.fillMaxWidth()) { Text("Take Control") }
                        if (serviceRunning) {
                            Text("A persistent notification should be visible while the service is active.", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }

                Card {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Activity log", style = MaterialTheme.typography.titleMedium)
                        Text("• App ready", style = MaterialTheme.typography.bodySmall)
                        Text("• Browser foundation loaded", style = MaterialTheme.typography.bodySmall)
                        Text("• Qureo automation: not connected yet", style = MaterialTheme.typography.bodySmall)
                    }
                }
                Text(
                    "Prototype build v0.1 · Browser and service foundation only. It does not yet read lessons, click Qureo controls, complete activities, or track real website progress.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.secondary
                )
            }
        }
    }
}

private suspend fun testGemini(key: String): String = withContext(Dispatchers.IO) {
    var connection: HttpURLConnection? = null
    try {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$key")
        connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 12000
            readTimeout = 20000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
        }
        val body = JSONObject().put(
            "contents",
            org.json.JSONArray().put(
                JSONObject().put("parts", org.json.JSONArray().put(JSONObject().put("text", "Reply with exactly: CONNECTED")))
            )
        ).toString()
        connection.outputStream.use { it.write(body.toByteArray()) }
        val code = connection.responseCode
        if (code in 200..299) {
            "Connected · Gemini responded successfully"
        } else {
            val error = connection.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
            "Connection failed (HTTP $code) · check the key or API access"
        }
    } catch (e: Exception) {
        "Connection failed · ${e.localizedMessage ?: "network error"}"
    } finally {
        connection?.disconnect()
    }
}
